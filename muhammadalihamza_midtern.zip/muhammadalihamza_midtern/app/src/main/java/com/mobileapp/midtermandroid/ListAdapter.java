package com.mobileapp.midtermandroid;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

public class ListAdapter extends ArrayAdapter<News>
{
    private int resourceLayout;
    private Context mContext;
    private List<News>itemList;

    public ListAdapter(Context context, int resource, List<News> items)
    {
        super(context, resource, items);
        this.resourceLayout = resource;
        this.itemList=items;
        this.mContext = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = convertView;

        if (v == null)
        {
            LayoutInflater vi;
            vi = LayoutInflater.from(mContext);
            v = vi.inflate(resourceLayout, null);
        }

        News item = getItem(position);

        TextView tvHeading=v.findViewById(R.id.tv_heading);
        TextView tvDesc=v.findViewById(R.id.tv_desc);
        TextView tvUrl=v.findViewById(R.id.tv_url);
        TextView tvID=v.findViewById(R.id.tv_id);
        ImageView img=v.findViewById(R.id.img_view);

        tvHeading.setText("Heading: "+item.getHeading());
        tvDesc.setText("Description: "+item.getDescription());
        tvUrl.setText("URL:"+item.getUrl());
        tvID.setText("ID:" +String.valueOf(item.getId()));
        Glide.with(mContext).load(item.getUrl()).into(img);

        return v;
    }

}
